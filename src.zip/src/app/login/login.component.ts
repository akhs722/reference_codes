import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from 'src/services/user.service';
import { ILoginStructure } from '../interfaces/user';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  status:boolean;
  useCredentials : ILoginStructure;
  constructor(private _userservice:UserService,private router:Router) { 
    
  }
  submitLoginForm(form: NgForm) {
   if(form.value.email != null && form.value.password != null)
   {
    this.useCredentials.email = form.value.email;
    this.useCredentials.password = form.value.password;
    this._userservice.ValidateUserCredentials(this.useCredentials).subscribe(
      x => {
          if(this.status == true)
          {
            sessionStorage.setItem('userEmail', form.value.email);
            this.router.navigate(['/userhome']);
          }
          else {
            alert("Try again with valid credentials");
            this.status = false;
          } 
      },
      y => {
        console.log(y);
      },
      () => console.log("method executed successfully")
    );
   }
   else
   {
     alert('All fields are mandatory');
   }
  }
  ngOnInit() {
  }

}
