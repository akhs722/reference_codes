import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-header-layout',
  templateUrl: './common-header-layout.component.html',
  styleUrls: ['./common-header-layout.component.css']
})
export class CommonHeaderLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
