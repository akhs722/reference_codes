import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonHeaderLayoutComponent } from './common-header-layout.component';

describe('CommonHeaderLayoutComponent', () => {
  let component: CommonHeaderLayoutComponent;
  let fixture: ComponentFixture<CommonHeaderLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonHeaderLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonHeaderLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
