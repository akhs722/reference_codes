import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  constructor() { }
  submitRegisterForm(form: NgForm) {

    alert(form.value.email);
    alert(form.value.password);
   }
  ngOnInit() {
  }

}
