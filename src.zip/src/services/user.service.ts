import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { ILoginStructure } from 'src/app/interfaces/user';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  Registeruser()
  {

  }
  ValidateUserCredentials(userCredentials : ILoginStructure) {
    
    return this.http.post<boolean>('http://localhost:49486/api/User/ValidateUserCredentials', userCredentials).pipe(catchError(this.errorHandler));
  }
  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }
}
