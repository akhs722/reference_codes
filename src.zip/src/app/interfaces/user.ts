export interface ILoginStructure {
    email: String, 
    password: string,
  }
  